<?php
if (!defined('ABSPATH')) {
    exit();
}

/*
title: [en_US:]PaymentCoinpay[:en_US][ru_RU:]PaymentCoinpay[:ru_RU]
description: [en_US:]CoinPay Payment merchant[:en_US][ru_RU:]мерчант CoinPay Payment[:ru_RU]
version: 2.2.4
 */

if(!class_exists('Merchant_Premiumbox')){ return; }

if (!class_exists('merchant_PaymentCoinpay')) {
    class merchant_PaymentCoinpay extends Merchant_Premiumbox
    {

        public function __construct($file, $title)
        {
            parent::__construct($file, $title, 1);

            $ids = $this->get_ids('merchants', $this->name);
            foreach ($ids as $id) {
                add_action('premium_merchant_' . $id . '_status' . hash_url($id), array($this, 'merchant_status'));
                add_action('premium_merchant_' . $id . '_order', array($this, 'order'));
            }
        }

        public function get_map()
        {
            $map = array(
                'CONFIRM_COUNT' => array(
                    'title' => '[en_US:]The required number of transaction confirmations[:en_US][ru_RU:]Количество подтверждения платежа, чтобы считать его выполненым[:ru_RU]',
                    'view' => 'input',
                ),
                'API_KEY' => array(
                    'title' => '[en_US:]Api key[:en_US][ru_RU:]Api key[:ru_RU]',
                    'view' => 'input',
                ),
                'API_SECRET' => array(
                    'title' => '[en_US:]Secret key[:en_US][ru_RU:]Secret key[:ru_RU]',
                    'view' => 'input',
                ),
            );
            return $map;
        }

        public function settings_list()
        {
            $arrs = array();
            $arrs[] = array('API_KEY', 'API_SECRET', 'CONFIRM_COUNT');
            return $arrs;
        }

        public function options($options, $data, $id, $place)
        {

            $options = pn_array_unset($options, 'personal_secret');
            $options = pn_array_unset($options, 'pagenote');
            $options = pn_array_unset($options, 'check_api');

            $text = '<div><strong>callback URL:</strong> <a href="' . get_mlink($id . '_status' . hash_url($id)) . '" target="_blank" rel="noreferrer noopener">' . get_mlink($id . '_status' . hash_url($id)) . '</a></div>';

            $options['private_line'] = array(
                'view' => 'line',
                'colspan' => 2,
            );

            $options[] = array(
                'view' => 'textfield',
                'title' => '',
                'default' => $text,
            );

            return $options;
        }

        public function bidaction($temp, $m_id, $pay_sum, $item, $direction)
        {
            $script = get_mscript($m_id);
            if ($script and $script == $this->name) {
                $m_defin = $this->get_file_data($m_id);

                $params = array(
                    'sum' => 0,
                    'm_place' => $this->name,
                    'system' => 'user',
                );
                set_bid_status('techpay', $item->id, $params, 0, $direction);

                $currency = pn_strip_input($item->currency_code_give);
                $item_id = $item->id;

                $locale = get_locale();
                if ($locale == 'ru_RU') {
                    $lang = 'ru';
                } else {
                    $lang = 'en';
                }

                $pay_sum = is_sum($pay_sum, 8);
                $text_pay = get_text_pay($m_id, $item, $pay_sum);

				$to_account = pn_strip_input($item->to_account);

                if (in_array($currency, array('BTC', 'ETH', 'USD', 'USDT'))) {
                    if (!$to_account) {
                        $m_data = get_merch_data($m_id);
                        $show_error = intval(is_isset($m_data, 'show_error'));

                        $email = $item->user_email;
                        $client_ip = $item->user_ip;
                        $callback_url = get_mlink($m_id . '_status' . hash_url($m_id));

                        try {
                            $class = new CoinApi(is_deffin($m_defin, 'API_KEY'), is_deffin($m_defin, 'API_SECRET'), $m_id);
                            $to_account = $class->generate_adress($item_id, $currency, $callback_url, $client_ip, $email);
                        } catch (Exception $e) {
                            if ($show_error) {
                                $this->wh_log('error', $e);
                                die($e);
                            }
                        }

                        if ($to_account) {
                            $to_account = pn_strip_input($to_account);
                            //
                            update_bid_tb($item_id, 'to_account', $to_account);

                            $item = pn_object_replace($item, array('to_account' => $to_account));

                            $notify_tags = array();
                            $notify_tags['[sitename]'] = pn_site_name();
                            $notify_tags['[bid_id]'] = $item_id;
                            $notify_tags['[address]'] = $to_account;
                            $notify_tags['[sum]'] = $pay_sum;
                            $notify_tags['[count]'] = intval(is_deffin($m_defin, 'CONFIRM_COUNT'));
                            $notify_tags = apply_filters('notify_tags_generate_address_askbtc', $notify_tags);

                            $user_send_data = array();
                            $result_mail = apply_filters('premium_send_message', 0, 'generate_address2_askbtc', $notify_tags, $user_send_data, get_admin_lang());

                            $user_send_data = array(
                                'user_email' => $item->user_email,
                            );
                            $user_send_data = apply_filters('user_send_data', $user_send_data, 'generate_address1_askbtc', $item);
                            $result_mail = apply_filters('premium_send_message', 0, 'generate_address1_askbtc', $notify_tags, $user_send_data, $item->bid_locale);

                        }
                    }

                    if ($to_account) {
                        if ($currency === 'BTC') {
                            $qr_code_protocol = 'bitcoin';
                        } elseif ($currency === 'ETH') {
                            $qr_code_protocol = 'ethereum';
                        } elseif ($currency === 'USDT') {
                            $qr_code_protocol = 'Tether';
                        } elseif ($currency === 'USD') {
                            $qr_code_protocol = 'usd';
                        } else {
                            $qr_code_protocol = null;
                        }

                        if (!empty($qr_code_protocol)) {
                            $qr_code_base = 'https://chart.googleapis.com/chart?chs=200x200&cht=qr&choe=UTF-8&chl=';
                            $qr_code_link = $qr_code_base . $to_account;
                            $qr_code_text = '<div class="zone_div">
                                                                    <div class="zone_title"><div class="">' . __('QR code', 'pn') . '</div></div>
                                                                    <div class="zone_text">
                                                                            <div style="padding: 20px 0; width: 260px; margin: 0 auto;">
                                                                                    <div id="qr_adress"><img width="200" heigth="200" src="' . $qr_code_link . '" /></div>
                                                                            </div>
                                                                    </div>
                                                            </div>';
                        }

                        $temp .= '
                                                            <div class="zone_table">
                                                                    <div class="zone_div">
                                                                            <div class="zone_title"><div class="zone_copy clpb_item" data-clipboard-text="' . $item_id . '"><div class="zone_copy_abs">' . __('copied to clipboard', 'pn') . '</div>' . __('ID', 'pn') . '</div></div>
                                                                            <div class="zone_text">' . $item_id . '</div>
                                                                    </div>
                                                                    <div class="zone_div">
                                                                            <div class="zone_title"><div class="zone_copy clpb_item" data-clipboard-text="' . $pay_sum . '"><div class="zone_copy_abs">' . __('copied to clipboard', 'pn') . '</div>' . __('Amount', 'pn') . '</div></div>
                                                                            <div class="zone_text">' . $pay_sum . ' ' . $currency . '</div>
                                                                    </div>
                                                                    <div class="zone_div">
                                                                            <div class="zone_title"><div class="zone_copy clpb_item" data-clipboard-text="' . $to_account . '"><div class="zone_copy_abs">' . __('copied to clipboard', 'pn') . '</div>' . __('Address', 'pn') . '</div></div>
                                                                            <div class="zone_text">' . $to_account . '</div>
                                                                    </div>
                                                                    ' . $qr_code_text . '
                                                            </div>
                                                            <div class="zone center">
                                                                    ' . sprintf(__('The order status changes to "Paid" when we get <b>%1$s</b> confirmations', 'pn'), is_deffin($this->m_data, 'CONFIRM_COUNT')) . '</p>
                                                            </div>
                                                    ';
                        // Change status of transaction to 'Waiting confirmation from merchant'
                        set_bid_status('techpay', $item_id, array(), 0, $direction);
                    } else {
                        $temp .= '<div class="error_div">' . __('Error', 'pn') . '</div>';
                        $this->wh_log('error', 'to_account not present');
                    }

                    
                    return $temp;
                    
                }

                if (in_array($currency, array('UAH', 'RUB'))) {
					if (!$to_account) {
						$m_data = get_merch_data($m_id);
                        $show_error = intval(is_isset($m_data, 'show_error'));
                        
                        $pay_sum = is_sum($pay_sum, 8);
                        $phone = $item->user_phone;
                        $email = $item->user_email;
                        $currency = pn_strip_input($item->currency_code_give);
                        $client_ip = $item->user_ip;

                        $callback_url = get_mlink($m_id . '_status' . hash_url($m_id));
                        $success_wallet_verification_url = get_mlink($m_id . '_order');

						try {
							$class = new CoinApi(is_deffin($m_defin, 'API_KEY'), is_deffin($m_defin, 'API_SECRET'), $m_id);
							$resp = $class->get_bill_form($item->id, $currency, $pay_sum, $callback_url, $phone, $email, $client_ip, $success_wallet_verification_url);
						} catch (Exception $e) {
						    $this->wh_log('error', $e);
							if ($show_error) {
								die($e);
							}
						}
                        
                        if ($resp['to_account']) {
							update_bid_tb($item_id, 'to_account', $resp['to_account']);
							$item = pn_object_replace($item, array('to_account' => $resp['to_account']));
                        }
                        
                        if ($resp['external_id']) {
							update_bid_tb($item_id, 'trans_in', $resp['external_id']);
							$item = pn_object_replace($item, array('trans_in' => $resp['external_id']));
                        }
                        
                        if ($resp['external_id']) {
                            set_bid_status('techpay', $item_id, array(), 0, $direction);
                            $temp .= '
                                <iframe src="' . $resp['to_account'] . '" style="width:500px; height:700px;" frameborder="0"></iframe>
                            ';
                            
                            return $temp;
                        }
                    }
                    
                    if ($to_account) {
                        header("Location: " . $to_account);
                    } else {
                        $temp .= '<div class="error_div">' . __('Error', 'pn') . '</div>';
                        return $temp;
                    }
                }
            }
        }

        public function order(){
            global $wpdb;

            $m_id = key_for_url('_order');
            $m_defin = $this->get_file_data($m_id);
            $m_data = get_merch_data($m_id);

            if (isset($_GET['orderId']) && $_GET['orderId'] != "") {
                $item = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "exchange_bids WHERE id='" . $_GET['orderId'] . "'");

                if (empty($item)) {
                    $this->wh_log('Error', "No order with this id");
                    $temp .= '<div class="error_div">' . __('Error', 'pn') . '</div>';
                    echo $temp;
                    return false;
                }

                $currency = pn_strip_input($item->currency_code_give);

                try {
                    $class = new CoinApi(is_deffin($m_defin, 'API_KEY'), is_deffin($m_defin, 'API_SECRET'), $m_id);
                    $resp = $class->deposit_deteils($item->trans_in, $currency);
                } catch (Exception $e) {
                    if ($show_error) {
                        $this->wh_log('error', $e);
                        die($e);
                    }
                }

                if ($resp->pay_url) {

                    $link = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

                    update_bid_tb($item->id, 'to_account', $link);
                    $item = pn_object_replace($item, array('to_account' => $link));

                    update_bid_tb($item->id, 'trans_in', $resp->pay_url);
                    $item = pn_object_replace($item, array('trans_in' => $resp->pay_url));

                    $temp .= '
                        <iframe src="' . $resp->pay_url . '" style="width:100%; height:800px;" frameborder="0"></iframe>
                    ';

                    echo $temp;
                } else {
                    $temp .= '<div class="error_div">' . __('Error', 'pn') . '</div>';
                    echo $temp;
                    return false;
                }
            } else {
                $temp .= '<div class="error_div">' . __('Error', 'pn') . '</div>';
                echo $temp;
                return false;
            }
        }

        public function merchant_status()
        {
            global $wpdb;

            $m_id = key_for_url('_status');
            $m_defin = $this->get_file_data($m_id);
            $m_data = get_merch_data($m_id);

            try {
                // Get callback input data
                $post_data = file_get_contents('php://input');

                if (empty($post_data)) {
                    $this->wh_log('error', 'Empty callback response');
                    throw new Exception('Empty callback response');
                }

                $json_params = json_decode($post_data);

                do_action('save_merchant_error', 'PaymentCoinpay', '_status: ' . json_encode($post_data));

                if (!$json_params || !isset($json_params->status)) {
                    $this->wh_log('error', 'Cant decode callback response');
                    throw new Exception("Can't decode callback response");
                }

                $class = new CoinApi(is_deffin($m_defin, 'API_KEY'), is_deffin($m_defin, 'API_SECRET'), $m_id);
                $resp = $class->order_details($json_params->order_id);
                if ($resp && isset($resp->status) && $resp->status == 'success') {
                    $order_id = $resp->order_details->customer_id;
                    $amount = $resp->order_details->amount;
                    $currency = $resp->order_details->currency;
                    $status = $resp->order_details->status;
                } else {
                    throw new Exception("Can't get order from API");
                }

                // Find transaction in DB
                $item = $wpdb->get_row('SELECT * FROM ' . $wpdb->prefix . "exchange_bids WHERE id='" . $order_id . "'");
                $id = intval(is_isset($item, 'id'));
                $data = get_data_merchant_for_id($id, $item);

                $bid_m_id = $data['m_id'];

                if (empty($item)) {
                    $this->wh_log('error', 'No transactions with specified xpay url');
                    throw new Exception('No transactions with specified xpay url');
                }

                if ($item->status === "success" || $item->status === "realpay" || $item->status === "verify") {
                    $this->wh_log('Status error', 'Заявка имеен неверный статус.');
                    do_action('save_merchant_error', 'PaymentCoinpay', 'Заявка имеен неверный статус. На момент колбека заявка уже была в скатусе: '. $item->status );
                    throw new Exception('Order has wrong status');
                }

                // Check trasaction data
                $transactionId = $item->id;

                $transactionData = get_data_merchant_for_id($transactionId, $item);

                $transaction_err = $transactionData['err'];
                $transaction_m_id = $transactionData['m_id'];

                if ($transaction_err !== 0) {
                    $this->wh_log('error', 'Bid does not exist or the wrong ID');
                    throw new Exception('Bid does not exist or the wrong ID');
                }

                $currency_to_spend = $item->currency_code_give;

                if ($currency != $currency_to_spend) {
                    $this->wh_log('error', 'Currency not equals with order.');
                    throw new Exception('Currency not equals with order.');
                }

                if ($status === "WAITING_FOR_CONFIRMATION") {
                    $now_status = 'coldpay';
                            set_bid_status($now_status, $id, array(), 0, $data['direction_data']);
                    die('ok');
                }

                if ($status === "ERROR") {
                    $now_status = 'error';
                    set_bid_status($now_status, $id, array(), 0, $data['direction_data']);
                    die('ok');
                        }

                if ($status === "CLOSED") {
                    if ($amount) {
                        $sumScale = ($currency === "UAH") ? 2 : 8;

                        if (is_sum($amount, $sumScale) < is_sum($item->sum1dc, $sumScale)) {
                            $transaction_sum = $amount;
                            $transaction_corr_sum = apply_filters('merchant_bid_sum', $transaction_sum, $transaction_m_id);

                            $now_status = 'verify';

                            $params = array(
                                'sum' => $amount,
                                'bid_sum' => $transaction_sum,
                                'bid_corr_sum' => $transaction_corr_sum,
                                'm_place' => $bid_m_id
                            );
                            $now_status = 'verify';
                            set_bid_status($now_status, $id, array(), 0, $data['direction_data']);
                            die('error');
                        }
                        $now_status = 'realpay';
                        set_bid_status($now_status, $id, array(), 0, $data['direction_data']);
                        die('ok');
                    } else {
                        $now_status = 'verify';
                        set_bid_status($now_status, $id, array(), 0, $data['direction_data']);
                        die('error');
                    }
                }
            } catch (Exception $e) {
                $this->wh_log('error', $e);
                die($e);
            }
        }

        public function wh_log($log_title, $log_msg)
        {
            $log_filename = getcwd() . '/wp-content/coinpay_payment.log';
            if (!file_exists($log_filename)) {
                $handle = fopen($log_filename, 'w');
                fclose($handle);
            }
            $log = $log_title . ': ' . $log_msg . ' - date: ' . date('F j, Y, g:i a') . PHP_EOL .
                '-------------------------' . PHP_EOL;
            file_put_contents($log_filename, $log, FILE_APPEND);
        }
    }
}

new merchant_PaymentCoinpay(__FILE__, 'PaymentCoinpay');