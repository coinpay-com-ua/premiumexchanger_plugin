<?php
if (!defined('ABSPATH')) {exit();}

if (!class_exists('CoinApi')) {
    class CoinApi
    {

        private $baseURL = "https://coinpay.org.ua/api/v1";
        private $sing_base = "/api/v1";
        private $api_key = "";
        private $secret_key = "";
        private $m_id = '';

        public function __construct($api_key, $secret_key, $m_id)
        {
            $this->api_key = trim($api_key);
            $this->secret_key = trim($secret_key);
            $this->m_id = trim($m_id);
        }

        public function generate_adress($order_id, $currency, $callback_url, $client_ip, $email)
        {      
            $info = array();
            $to_sign = array();

            $info['client_ip'] = $client_ip;
            $info['customer_id'] = $order_id;
            $info['deposit_email'] = $email;
            $to_sign['additional_info_client_ip'] = $client_ip;
            $to_sign['additional_info_customer_id'] = $order_id;
            $to_sign['additional_info_deposit_email'] = $email;
            
            $currency = strtoupper($currency);

            $params = array(
                "callback_url" => $callback_url,
                "currency" => $currency
            );

            $result = $this->request('/deposit/address', $params, 'POST', $info, $to_sign);

            $address = (isset($result->status) && $result->status === "success" && isset($result->addr)) ? $result->addr : null;

            if (empty($address)) {
                $this->wh_log('error', 'No wallet address for currency');
                throw new Exception("No wallet address for $currency currency");
            }

            return $address;
            /* или массив или пустота */
        }

        public function get_bill_form($order_id, $currency, $pay_sum, $callback_url, $phone, $email, $client_ip, $success_wallet_verification_url)
        {   
            $info = array();
            $to_sign = array();

            $info['client_ip'] = $client_ip;
            $info['customer_id'] = $order_id;
            $info['deposit_email'] = $email;
            $to_sign['additional_info_client_ip'] = $client_ip;
            $to_sign['additional_info_customer_id'] = $order_id;
            $to_sign['additional_info_deposit_email'] = $email;

            if ($phone) {
                $info['deposit_phone'] = $phone;
                $to_sign['additional_info_deposit_phone'] = $phone;
            }

            $params = array(
                'amount_to_spend' => $pay_sum,
                'callback_url' => $callback_url,
                'currency' => $currency,
                'success_url' => $success_wallet_verification_url . "?orderId=" . $order_id
            );

            $result = $this->request('/deposit/address', $params, 'POST', $info, $to_sign);

            $data = array(
                'to_account' => $result->addr,
                'external_id' => $result->external_id,
            );

            return $data;
        }

        public function deposit_deteils($external_id, $currency){
            $params = array(
                'currency' => $currency,
                'external_id' => $external_id
            );

            $result = $this->request('/deposit/address/details', $params, 'GET');

            return $result;
        }

        public function order_details($order_id)
        {
            $params = array(
                'order_id' => $order_id,
            );

            $result = $this->request('/orders/details', $params, 'GET');

            return $result;
            /* или массив или пустота */
        }

        public function order_history($currency, $address)
        {
            $params = array(
                'address' => $address,
                'currency' => $currency,
                'order_sub_type' => 'GATEWAY',
                'order_type' => 'DEPOSIT',
            );

            $result = $this->request('/orders/history', $params, 'GET');

            return $result;
            /* или массив или пустота */
        }

        public function balance()
        {
            $params = array();
            $result = $this->request('/user/balance', $params, 'GET');
            return $result;
        }

        public function request($api_name, $req = array(), $method, $info = NULL, $to_sign = NULL)
        {
            $url = $this->baseURL . $api_name;

            $headers = array(
                'Content-Type: application/json',
                'Accept: application/json',
            );

            if($info) {
                $addinfo_string = str_replace('%3D', '=', rawurlencode(http_build_query($to_sign, '', '&')));
                $addinfo_string = str_replace('%26', '&', $addinfo_string);
                $addinfo_string = str_replace('%25', '%', $addinfo_string);
                $data = $method . "-" . $this->sing_base . $api_name . "-" . $addinfo_string . '&' . http_build_query($req, '', '&');
                $req['additional_info'] = $info;
            } else {
                $data = $method . "-" . $this->sing_base . $api_name . "-" . http_build_query($req, '', '&');
            }

            $signature = hash_hmac('sha256', trim(utf8_encode($data)), $this->secret_key);
            
            $headers[] = 'Sign:' . $signature;
            $headers[] = 'Key:' . $this->api_key;

            $c_options = array(
                CURLOPT_FOLLOWLOCATION => 1,
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_HTTPHEADER => $headers,

                CURLINFO_HEADER_OUT => true,
                CURLOPT_MAXREDIRS => 3,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
                CURLOPT_ENCODING => '',
                CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_SSL_VERIFYPEER => false,
            );

            if ($method === "POST") {
                $post_data = json_encode($req, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                $c_options[CURLOPT_POSTFIELDS] = $post_data;
            } else {
                $get_params = http_build_query($req, '', '&');
                if ($api_name !== "/user/balance") {
                    $url = $url . '?' . urldecode($get_params);
                }
						}

            $result = get_curl_parser($url, $c_options, 'merchant', 'coinpay', $this->m_id);
            $result = json_decode($result["output"]);

            do_action('save_merchant_error', 'Coinpay', 'result: ' . print_r($result, true));

            $err = false;
            if (!$result || empty($result)) {
                $this->wh_log('Error', 'Empty JSON response.');
                $err = "Empty JSON response.";
            } elseif (isset($result->status) && $result->status === "error") {
                $err = (isset($result->detail)) ? $result->detail : "Unknown API error.";

                $this->wh_log("Error", json_encode($err));

                if (json_encode($err) == json_encode("Dear Customer! Only one order should be active")) {
                    return $err;
                } else {
                    return false;
                }
                
            }

            if (!$err) {
                return $result;
            }
        }

        public function wh_log($log_title, $log_msg)
        {
            $log_filename = getcwd() . '/wp-content/coinpay_payment.log';
            if (!file_exists($log_filename)) {
                $handle = fopen($log_filename, 'w');
                fclose($handle);
            }
            $log = $log_title . ': ' . $log_msg . ' - date: ' . date('F j, Y, g:i a') . PHP_EOL .
                '-------------------------' . PHP_EOL;
            file_put_contents($log_filename, $log, FILE_APPEND);
        }
    }
}