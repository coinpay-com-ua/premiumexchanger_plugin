<?php
if ( !class_exists( 'AP_CoinPay' ) ) {
    class AP_CoinPay {

        private $baseURL = 'https://coinpay.org.ua/api/v1';
        private $sing_base = '/api/v1';
        private $api_key = '';
        private $secret_key = '';
        private $m_id = '';

        function __construct( $api_key, $secret_key, $m_id ) {
            $this->api_key = trim( $api_key );
            $this->secret_key = trim( $secret_key );
            $this->m_id = trim( $m_id );
        }

        public function withdraw($amount, $receiver, $currency, $email, $callbacl_url, $item_id)
        {
					$info = array();
					$to_sign = array();

					if ($email) {
							$info['withdrawal_email'] = $email;
							$to_sign['additional_info_withdrawal_email'] = urlencode($email);
					}

					$parameters = array(
						"amount" => $amount,
						"callback_url" => $callbacl_url,
						"comment" => "Payout order: " . $item_id,
						"currency" => $currency,
						"wallet_to" => $receiver,
						"withdrawal_type" => "GATEWAY"
					);

					$res = $this->request('/withdrawal', $parameters, "POST", $info, $to_sign);
					return $res;
					/* или данные или пустота */
        }

        public function get_balance() {
					$result = $this->request('/user/balance', array(), 'GET');
					$purses = array();

					foreach ($result->balance as $currencyBase => $currencyResponse) {
							$currency = trim($currencyBase);
							$value = trim($currencyResponse->$currencyBase->total);
							$purses[$currency] = $value;
					}

					return $purses;
					/* или массив или пустота */
				}
				
				public function order_details($order_id)
        {
            $params = array(
                'order_id' => $order_id,
            );

            $result = $this->request('/orders/details', $params, 'GET');

            return $result;
            /* или массив или пустота */
        }
				
				public function request($api_name, $req = array(), $method, $info = NULL, $to_sign = NULL)
        {
					$url = $this->baseURL . $api_name;

					$headers = array(
							'Content-Type: application/json',
							'Accept: application/json',
					);

					if($info) {
						$addinfo_string = str_replace('%25', '%', http_build_query($to_sign, '', '&'));
						$data = $method . "-" . $this->sing_base . $api_name . "-" . $addinfo_string . '&' . http_build_query($req, '', '&');
						$req['additional_info'] = $info;
					} else {
						$data = $method . "-" . $this->sing_base . $api_name . "-" . http_build_query($req, '', '&');
					}
					
					$signature = hash_hmac('sha256', trim(utf8_encode($data)), $this->secret_key);

					$headers[] = 'Sign:' . $signature;
					$headers[] = 'Key:' . $this->api_key;

					$c_options = array(
							CURLOPT_FOLLOWLOCATION => 1,
							CURLOPT_CUSTOMREQUEST => $method,
							CURLOPT_HTTPHEADER => $headers,

							CURLINFO_HEADER_OUT => true,
							CURLOPT_MAXREDIRS => 3,
							CURLOPT_CONNECTTIMEOUT => 5,
							CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
							CURLOPT_ENCODING => '',
							CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
							CURLOPT_RETURNTRANSFER => 1,
							CURLOPT_SSL_VERIFYPEER => false,
					);

					if ($method === "POST") {
							$post_data = json_encode($req, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
							$c_options[CURLOPT_POSTFIELDS] = $post_data;
							do_action('save_merchant_error', 'coinpay', 'post:' . print_r($post_data, true));
					} else {
							$get_params = http_build_query($req, '', '&');
							if ($api_name !== "/user/balance") {
									$url = $url . '?' . urldecode($get_params);
							}
					}

					$result = get_curl_parser( $url, $c_options, 'autopay', 'coinpay', $this->m_id);
					do_action('save_merchant_error', 'coinpay', 'result:' . print_r($result, true));

					$result = json_decode($result["output"]);

					$err = false;
					if (!$result || empty($result)) {
							$err = "Failed parse JSON response.";
					} elseif (isset($result->status) && $result->status === "error") {
							$err = (isset($result->detail)) ? $result->detail : "Unknown API error.";
							$this->wh_log("Error", json_encode($err));
							return $err;
					}

					if (!$err) {
							return $result;
					} 

					return false;
				}

        public function wh_log( $log_title, $log_msg )
        {
            $log_filename = getcwd() . '/wp-content/coinpay.log';
            if ( !file_exists( $log_filename ) ) {
                $handle = fopen( $log_filename, 'w' );
                fclose( $handle );
            }
            $log  = $log_title . ': ' . $log_msg . ' - date: ' . date( 'F j, Y, g:i a' ) . PHP_EOL .
            '-------------------------' . PHP_EOL;
            file_put_contents( $log_filename, $log, FILE_APPEND );
        }
    }
}