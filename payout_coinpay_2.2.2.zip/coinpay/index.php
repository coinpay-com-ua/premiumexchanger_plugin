<?php
if (!defined('ABSPATH')) {
    exit();
}

/*
title: [en_US:]CoinPay[:en_US][ru_RU:]CoinPay[:ru_RU]
description: [en_US:]CoinPay automatic payouts[:en_US][ru_RU:]авто выплаты CoinPay[:ru_RU]
version: 2.2.2
 */

if (!class_exists('AutoPayut_Premiumbox')) {
    return;
}

if (!class_exists('paymerchant_coinpay')) {
    class paymerchant_coinpay extends AutoPayut_Premiumbox
    {
        public function __construct($file, $title)
        {
            parent::__construct($file, $title, 1);

            $ids = $this->get_ids('paymerchants', $this->name);
			foreach($ids as $m_id){
                add_action('premium_merchant_ap_'. $m_id .'_status' . hash_url($m_id, 'ap'), array($this,'status'));
			}
        }

        public function get_map()
        {
            $map = array(
                'API_KEY' => array(
                    'title' => '[en_US:]Api key[:en_US][ru_RU:]Api key[:ru_RU]',
                    'view' => 'input',
                ),
                'API_SECRET' => array(
                    'title' => '[en_US:]Secret key[:en_US][ru_RU:]Secret key[:ru_RU]',
                    'view' => 'input',
                ),
            );
            return $map;
        }

        public function settings_list()
        {
            $arrs = array();
            $arrs[] = array('API_KEY', 'API_SECRET');
            return $arrs;
        }

        public function options($options, $data, $id, $place)
        {

            $options = pn_array_unset($options, 'checkpay');
            
            $options[] = array(
                'view' => 'textfield',
                'title' => '',
                'default' => $text,
            );

            return $options;
        }

        public function get_reserve_lists($m_id, $m_defin)
        {
            $purses = array(
                $m_id . '_1' => 'UAH',
                $m_id . '_2' => 'EUR',
                $m_id . '_3' => 'USD',
                $m_id . '_4' => 'BTC',
                $m_id . '_5' => 'ETH',
                $m_id . '_6' => 'USDT',
                $m_id . '_7' => 'RUB',
            );
            return $purses;
        }

        public function update_reserve($code, $m_id, $m_defin)
        {

            $sum = 0;

            $purses = $this->get_reserve_lists($m_id, $m_defin);
            $purse = trim(is_isset($purses, $code));
            if ($purse) {
                try {

                    $class = new AP_CoinPay(is_deffin($m_defin, 'API_KEY'), is_deffin($m_defin, 'API_SECRET'), $m_id);
                    $res = $class->get_balance();

                    if (is_array($res)) {
                        $rezerv = '-1';
                        foreach ($res as $pursename => $amount) {
                            if ($pursename == $purse) {
                                $rezerv = trim((string) $amount);
                                break;
                            }
                        }
                        if ($rezerv != '-1') {
                            $sum = $rezerv;
                        }
                    }

                } catch (Exception $e) {
                    $this->wh_log('Update reserve', json_encode($e));
                }

            }

            return $sum;
        }

        public function do_auto_payouts($error, $pay_error, $m_id, $item, $place, $direction_data, $paymerch_data, $unmetas, $modul_place, $direction, $test, $m_defin)
        {
            global $wpdb;

            $trans_out = 0;
            $item_id = $item->id;

            $currency = mb_strtoupper($item->currency_code_get);
            $currency = str_replace('UAH', 'UAH', $currency);

            $enable = array('UAH', 'EUR', 'USD', 'BTC', 'ETH', 'USDT', "RUB");

            if (!in_array($currency, $enable)) {
                $error[] = __('Wrong currency code', 'pn');
                $this->wh_log('error', 'Wrong currency code');
            }

            $account = $item->account_get;
            $account = preg_replace('/\s/', '', $account);

            $sum = is_sum(is_paymerch_sum($item, $paymerch_data), 8);
            $email = $item->user_email;
            $callbacl_url = get_mlink('ap_'. $m_id .'_status' . hash_url($m_id, 'ap'));

            $two = array('UAH');
            if (in_array($currency, $two)) {
                $sum = is_sum(is_paymerch_sum($item, $paymerch_data), 8);
            } else {
                $sum = is_sum(is_paymerch_sum($item, $paymerch_data), 8);
            }

            if (count($error) == 0) {
                $result = $this->set_ap_status($item, $test);

                if ($result) {
                    $notice = get_text_paymerch($m_id, $item);
                    $notice = trim(pn_maxf($notice, 100));

                    try {
                        $class = new AP_CoinPay(is_deffin($m_defin, 'API_KEY'), is_deffin($m_defin, 'API_SECRET'), $m_id);
                        $res = $class->withdraw($sum, $account, $currency, $email, $callbacl_url, $item_id);

                        if (isset($res->status) && $res->status === 'success') {
                            $trans_out = $res->order_id;
                        } else {
                            $this->wh_log('error', 'Data from api not received');
                            $error[] = $res;
                            $pay_error = 1;
                        }

                    } catch (Exception $e) {
                        $error[] = $e->getMessage();
                        $this->wh_log('error', $e->getMessage());
                        $pay_error = 1;
                    }
                } else {
                    $error[] = 'Database error';
                }
            }

            if (count($error) > 0) {
                $this->reset_ap_status($error, $pay_error, $item, $place, $test);
            } else {
                $params = array(
                    'trans_out' => $trans_out,
                    'system' => 'user',
                    'ap_place' => $place,
                    'm_place' => $modul_place . ' ' . $m_id,
                );

                set_bid_status('coldsuccess', $item_id, $params, 1, $direction);

                if ($place == 'admin') {
                    pn_display_mess("Заявка на выплату создана.", __('Заявка на выплату создана.', 'pn'), 'true');
                }

            }

        }

        public function status(){
            global $wpdb;
            
            
            $m_id = key_for_url('_status', 'ap_');
            $m_defin = $this->get_file_data($m_id);
            $m_data = get_paymerch_data($m_id);

            // Get callback input data
            $post_data = file_get_contents('php://input');

            if (empty($post_data)) {
                $this->wh_log('error', 'Empty callback response');
                throw new Exception('Empty callback response');
            }

            do_action('save_merchant_error', 'Payout CoinPay', '_status: ' . json_encode($post_data));

            $json_params = json_decode($post_data);

            $class = new AP_CoinPay(is_deffin($m_defin, 'API_KEY'), is_deffin($m_defin, 'API_SECRET'), $m_id);
            $resp = $class->order_details($json_params->external_id);
            if ($resp && isset($resp->status) && $resp->status == 'success') {
                $external_id = $resp->order_details->external_id;
                $status =  $resp->order_details->status;
                $order_type = $resp->order_details->order_type;
                $currency = $resp->order_details->currency;
            } else {
                throw new Exception("Can't get order from API");
            }

            if($external_id){
                $item = $wpdb->get_row('SELECT * FROM ' . $wpdb->prefix . "exchange_bids WHERE status = 'coldsuccess' AND trans_out='" . $external_id . "'");
                $item_currency = mb_strtoupper($item->currency_code_get);
                $id = intval(is_isset($item, 'id'));
                $data = get_data_merchant_for_id($id, $item);

                $bid_m_id = $data['m_id'];
                
                if($order_type === "WITHDRAWAL" and $currency == $item_currency){
                    if ($status === 'CLOSED') {
                        $params = array(
                            'system' => 'system',
                            'ap_place' => 'site',
                            'm_place' => $bid_m_id,
                        );
                        set_bid_status('success', $item->id, $params, 0, $data['direction_data']);	
                    }
                    if ($status === 'ERROR') {
                        $params = array(
                            'system' => 'system',
                            'ap_place' => 'site',
                            'm_place' => $bid_m_id,
                        );
                        set_bid_status('payouterror', $item->id, $params, 0, $data['direction_data']);	
                    }												
                }
            }
    
            _e('Done','pn');			
        }

        public function wh_log( $log_title, $log_msg )
        {
            $log_filename = getcwd() . '/wp-content/coinpay.log';
            if ( !file_exists( $log_filename ) ) {
                $handle = fopen( $log_filename, 'w' );
                fclose( $handle );
            }
            $log  = $log_title . ': ' . $log_msg . ' - date: ' . date( 'F j, Y, g:i a' ) . PHP_EOL .
            '-------------------------' . PHP_EOL;
            file_put_contents( $log_filename, $log, FILE_APPEND );
        }
    }
}

new paymerchant_coinpay(__FILE__, 'CoinPay');